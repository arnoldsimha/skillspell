# Arc

This skill helps the agent produce high-quality architectural documents that communicate
technical decisions clearly. It supports three document types — Architecture Decision Records
(ADRs), system design documents, and technical architecture documents — each with structured
templates enforcing best practices like explicit problem statements, alternatives analysis,
trade-off matrices, and decision rationale.

**Critical principle: The agent's primary job is to PRODUCE the completed document, not to
prepare endlessly. Reference files are aids, not prerequisites. If the user provides enough
context, the agent writes the document directly using the inline guidance below. The agent
only reads reference files when it genuinely lacks knowledge for a specific section.**

## Instructions

### Step 1: Identify Document Type and Gather Context

1. The agent determines which document type the user needs.
   - **ADR** — for recording a single architectural decision with its context and consequences.
   - **System Design Document** — for describing the design of a new system or major feature.
   - **Technical Architecture Document** — for documenting the overall architecture of a system or platform.

2. **Recognizing implicit requests.** Users often need architectural documents without using
   architecture terminology. The agent watches for these implicit signals and classifies them:

   | Implicit Signal | Likely Document Type | Why |
   |----------------|---------------------|-----|
   | Rebuilding, rewriting, or replacing a system | System Design | User is designing a new system to replace an existing one |
   | "Should we switch to X?" or "X vs Y for our Z" | ADR | User is weighing alternatives — the core of an architectural decision |
   | Scaling concerns ("won't handle 10x traffic") | ADR or System Design | Scaling triggers either a targeted decision or a broader redesign |
   | Cross-team coordination on technical approach | ADR | Multiple teams need a shared, documented decision record |
   | "How should we structure X?" for a new system | System Design | User is asking for design guidance on something being built |
   | "Document how our platform works" | Tech Architecture | User wants to capture existing architecture for onboarding or review |

   **Concrete examples of implicit requests and how the agent responds:**

   - **"We're rebuilding our payment service from scratch."**
     The agent recognizes this as a System Design need. The user is designing a new system.
     Response: "It sounds like you're designing a new payment service. I'll create a system
     design document that covers the problem statement, component design, data model, and
     deployment plan. What problem is the current service failing to solve?"

   - **"Should we switch from PostgreSQL to DynamoDB for our user profiles?"**
     The agent recognizes this as an ADR need. The user is choosing between two alternatives
     for a specific component.
     Response: "This is a classic architecture decision — I'll create an ADR that evaluates
     PostgreSQL vs DynamoDB (and any other options worth considering) with a structured
     trade-off analysis. What's driving the consideration — scale, cost, or something else?"

   - **"Our API gateway won't handle the traffic when we launch in Europe."**
     The agent recognizes this as either an ADR (if the decision is narrow, e.g., which
     gateway to use) or a System Design (if a broader redesign is needed). The agent asks
     a clarifying question to determine scope.
     Response: "Are you looking to decide on a specific scaling approach for the gateway
     (I'd write an ADR), or is this part of a broader redesign of your edge infrastructure
     (I'd write a system design document)?"

   - **"Three teams need to agree on how we handle authentication across all services."**
     The agent recognizes this as an ADR need. Cross-team technical alignment is best
     captured as a formal decision record.
     Response: "Cross-team authentication decisions are exactly what ADRs are for — they
     create a durable record everyone can reference. I'll structure it with the alternatives,
     trade-offs, and consequences so all three teams can review. What authentication
     approaches are on the table?"

   When the agent detects an implicit signal, it confirms the document type with the user
   before proceeding, briefly explaining why that type fits. This avoids surprising the user
   while still being proactive.

3. If the request is ambiguous even after checking implicit signals, the agent reads
   `references/document-type-guide.md` for selection criteria. Otherwise, the agent proceeds directly.

4. The agent extracts from the user's message (asking only for what is missing):
   - **Problem statement**: What problem or need does this architecture address?
   - **Scope**: What parts of the system are affected?
   - **Constraints**: Budget, timeline, team size, technology mandates, compliance.
   - **Stakeholders**: Decision makers and affected parties.
   - **Alternatives**: Options considered or to be evaluated.

5. If the user provides a codebase, the agent examines relevant source files to understand current architecture.

6. If the document is an ADR, the agent runs `scripts/list-adrs.sh <adr-directory>` to survey existing decisions (if a directory exists).

### Step 2: Write the Complete Document

The agent now writes the full document in one pass. The agent does NOT stop to read additional files unless it genuinely needs guidance on a specific section. The agent uses the structural patterns below.

**Writing the Problem Statement:**

The problem statement is the foundation of every architecture document — a weak one undermines
the entire decision. The agent validates every problem statement against the three anti-patterns
below before proceeding. If the draft matches any anti-pattern, the agent rewrites it before
continuing. This validation is mandatory, not optional, because reviewers judge the entire
document by the quality of its problem statement.

#### Anti-Pattern 1: Solution-Focused Language

The problem statement names a technology, pattern, or migration target instead of describing the pain.

**Bad:**
> We need to use Event Sourcing for our order management system because the current CRUD
> approach doesn't capture the full history of state changes and Event Sourcing is the
> industry best practice for audit trails.

**Why it fails:** Names the solution (Event Sourcing), frames the problem around the fix
instead of the user/business impact, and appeals to "best practice" instead of data.

**Good:**
> Our order management system cannot reconstruct how an order reached its current state,
> which forces the support team to spend an average of 45 minutes per escalation manually
> piecing together logs. We receive 120 escalations per week, and our SOC 2 audit in Q3
> requires a complete audit trail for every state transition. Without a reliable history
> mechanism, we risk both audit failure and continued support cost growth.

**Why it works:** Describes the pain (can't reconstruct state), quantifies it (45 min × 120/week),
explains urgency (SOC 2 in Q3), and names no solution.

#### Anti-Pattern 2: Vague Scope

The problem statement uses unmeasurable words like "slow", "better", "improve" without numbers.

**Bad:**
> System is slow and users are complaining. We need to improve performance to provide a
> better user experience.

**Why it fails:** "Slow" and "better" are unmeasurable. No indication of which component,
how many users are affected, or what "good" looks like.

**Good:**
> The product search API has a p99 latency of 4.2 seconds, which exceeds our 1-second
> SLO and is the top driver of cart abandonment — 23% of users who experience a slow
> search drop off before completing a purchase. Our peak traffic season starts in 8 weeks.

**Why it works:** Pinpoints the component (product search API), quantifies the gap
(4.2s vs 1s SLO), ties to business impact (23% cart abandonment), and states urgency (8 weeks).

#### Anti-Pattern 3: Missing Urgency

The problem statement describes a real issue but gives no reason to act now.

**Bad:**
> Data consistency is important for our distributed services. We should probably address
> the eventual consistency issues at some point since they sometimes cause problems.

**Why it fails:** "At some point" and "sometimes" signal no urgency. No deadline, threshold,
or blocker. No quantified impact.

**Good:**
> Our inventory service and order service disagree on stock levels for an average of 47
> seconds after each update, causing 3.2% of orders to oversell — resulting in $180K in
> refunds last quarter. The holiday traffic surge (3x baseline) begins November 1, which
> will amplify the oversell rate proportionally unless we reduce the consistency window
> below 5 seconds.

**Why it works:** Quantifies the gap (47 seconds), the impact (3.2% oversell, $180K refunds),
and the deadline (November 1 traffic surge).

#### Problem Statement Validation Checklist

After drafting, the agent checks every item before proceeding:

- [ ] **Business/user language**: Describes impact in user, business, or operational terms — not implementation details
- [ ] **No solution language**: Does not mention the proposed solution, specific technologies, or architectural patterns
- [ ] **Quantified scope**: Includes at least one concrete metric, threshold, or measurable impact
- [ ] **Explains "why now"**: States a clear trigger — deadline, threshold, compliance date, or scaling inflection point
- [ ] **2-5 sentences**: Long enough to convey context, short enough to stay focused

If any item fails, the agent rewrites the problem statement before moving on. For additional
before/after examples and a detailed common-mistakes reference table, the agent can consult
`references/problem-statement-validation.md`.

#### For ADRs, the agent produces this structure:

```markdown
# ADR-NNNN: [Short Title]

**Status:** [Proposed | Accepted | Deprecated | Superseded]
**Date:** [YYYY-MM-DD]
**Decision makers:** [Names or roles]

## Context
[Current situation, forces at play, why a decision is needed now]

## Problem Statement
[2-5 sentences. Business/user terms. No solution language. Why now.]

## Alternatives Considered
### Option N: [Name]
[Summary, how it addresses the problem, key characteristics]

## Trade-off Analysis
| Dimension | Option 1 | Option 2 | ... |
|-----------|----------|----------|-----|
| [Dim]     | [Rating — justification] | [Rating — justification] | ... |
(At least 4 dimensions. Every cell has rating + justification.)

## Decision
[Chosen option. Why. Reference specific trade-off results.]

## Consequences
### Positive
### Negative
### Neutral
(Each consequence is one concrete sentence.)

## Decision Triggers
[Conditions to revisit this decision.]
```

#### For System Design Documents, the agent reads `assets/system-design-template.md` for the full structure.

#### For Technical Architecture Documents, the agent reads `assets/tech-architecture-template.md` for the full structure.

#### Writing rules (inline — do NOT read writing-guide.md for these):

- **Problem statements**: Business/user terms, not implementation terms. No solution names. 2-5 sentences. Must explain "why now." Validate against the inline anti-patterns and checklist above.
- **Alternatives**: 2-5 options. Every alternative must be genuinely viable (no straw men). Include "status quo" when applicable.
- **Trade-off ratings**: High / Medium / Low / N/A — every rating needs a one-line justification.
- **Consequences**: Concrete and specific. "p99 latency drops from 850ms to 200ms" not "system is faster."
- **Terminology**: One term per concept, consistent throughout. Define acronyms on first use.

For detailed examples of good vs bad writing beyond problem statements, the agent reads `references/writing-guide.md` only if needed.

### Step 3: Add Diagrams

1. For system design and tech architecture documents, the agent includes at least one Mermaid diagram.
2. For ADRs, diagrams are optional but recommended when the decision involves component interactions.
3. The agent uses Mermaid syntax. If unfamiliar with a specific diagram type, the agent reads `references/diagram-guide.md`.
4. Every diagram gets a title heading and brief description.

### Step 4: Add Implementation Roadmap (Accepted ADRs)

This step is MANDATORY for ADRs with status `Accepted`. It bridges the decision to execution.

For ADRs with status `Proposed`, the agent asks: "Would you like an implementation roadmap now, or later when the decision is accepted?"

The agent appends the following sections directly after Decision Triggers in the ADR:

```markdown
## Implementation Roadmap

### Current State Assessment
[Describe the existing system state that will change. Components, data flows,
integration points affected.]

### Migration Phases

#### Phase 1: [Phase Name]
- **Objective:** [What this phase achieves]
- **Deliverable:** [Concrete output]
- **Effort:** [S / M / L / XL] — [Rationale]
- **Steps:**
  1. [Step]
  2. [Step]

#### Phase 2: [Phase Name]
[Same structure as Phase 1]

(Add more phases as needed.)

### Dependencies and Blockers
| Dependency | Type | Owner | Status | Mitigation if Blocked |
|-----------|------|-------|--------|-----------------------|
| [Dep 1]  | Technical / Team / External | [Owner] | [Status] | [Mitigation] |

## Success Metrics
| Metric | Current Value | Target Value | Measurement Method |
|--------|--------------|-------------|--------------------|
| [e.g., p99 latency] | [e.g., 850ms] | [e.g., < 200ms] | [e.g., Datadog APM] |
(3-5 measurable metrics. Concrete numbers, not vague.)

## Rollback Plan
- **Trigger:** [Condition that activates rollback]
- **Procedure:**
  1. [Rollback step]
  2. [Rollback step]
- **Data considerations:** [How to handle data written during failed migration]
- **Estimated rollback time:** [Duration]
```

For the full template with additional examples, the agent reads `assets/implementation-plan-template.md` only if it needs more structure.

Key rules for the roadmap:
- Migration steps must be ordered phases with clear deliverables.
- Dependencies include technical, team, and external with mitigations.
- Effort uses t-shirt sizes (S/M/L/XL) with rationale. No calendar dates unless user provides timeline.
- Success metrics must be measurable: current value, target value, how measured.
- Rollback plan is mandatory — how to revert if implementation fails.
- For greenfield (no existing system), write "Build Phases" instead of "Migration Phases" and skip Current State Assessment.

### Step 5: Validate and Deliver

1. The agent reviews the document against these checks:
   - Problem statement passes the inline validation checklist (no solution language, quantified, explains "why now", 2-5 sentences)
   - At least 2 alternatives listed, each with name and summary
   - Trade-off matrix has 4+ dimensions, every cell has rating + justification
   - Decision names chosen option and references trade-off results
   - Consequences are concrete, not vague
   - No placeholder text (TODO, TBD, TBC, FIXME) remains
   - For Accepted ADRs: Implementation Roadmap, Success Metrics, and Rollback Plan are present and filled in
2. If saving to a file, the agent runs `scripts/validate-doc.sh <path> <type>` for automated checks.
3. If saving an ADR, the agent runs `scripts/next-adr-number.sh <adr-directory>` for the next sequential number.
4. The agent names ADR files using `NNNN-short-title.md` convention.
5. The agent presents the completed document to the user.

## Error Handling

### Insufficient User Input

1. If the user provides only a topic with no context, the agent asks targeted questions:
   - "What problem is this meant to solve?"
   - "What alternatives have you considered?"
   - "Who are the stakeholders?"
2. The agent does not proceed until it has a problem statement and at least two alternatives.
3. If the user asks to skip context gathering, the agent produces the document with callouts: `> **Assumption:** [what was assumed and why]`.

### Ambiguous Document Type

1. The agent presents options and asks the user to choose.
2. Default: system design for new systems, tech architecture for existing systems.

### Contradictory Information

1. The agent flags contradictions explicitly and asks the user to resolve before continuing.
2. If alternatives overlap, the agent asks for distinguishing characteristics.

### Missing Codebase Access

1. The agent asks the user to describe: tech stack, architectural patterns, and relevant pain points.
2. The agent notes the limitation: `> **Note:** Architecture analysis based on user description; codebase not directly examined.`

### Script Execution Failures

1. If `scripts/list-adrs.sh` fails (directory not found), the agent asks user to create it or specify path.
2. If `scripts/validate-doc.sh` fails, the agent falls back to manual validation using Step 5 checks.
3. If `scripts/next-adr-number.sh` fails, the agent scans the directory manually and starts at `0001` if empty.
4. For permission errors, the agent suggests `chmod +x scripts/<script-name>.sh`.

### Superseding Existing ADRs

1. The agent adds `Superseded by` reference to old ADR and sets status to `Superseded`.
2. The agent confirms with user before modifying existing files.

### Incomplete Trade-off Data

1. The agent marks unknown cells as `Unknown — insufficient data to evaluate`.
2. The agent lists gaps and asks user for missing information.
3. Unknown cells do not block delivery, but the agent warns the analysis is incomplete.

### Implementation Roadmap Issues

1. If user cannot provide enough detail, the agent generates a skeleton with `> **Needs Input:** [what is missing]`.
2. For greenfield, the agent writes Build Phases instead of Migration Phases.
3. If timeline constraints conflict with effort (e.g., 2 weeks for XL), the agent flags the mismatch.

## Edge Cases

### Single Alternative

The agent adds "Status Quo / Do Nothing" to ensure at least two alternatives are considered.

### Retroactive Documentation

1. The agent sets status to `Accepted` with original decision date, writes Context in past tense.
2. The agent asks: "When was this decision originally made?" and "Is implementation completed or in progress?"
3. For completed implementations, the roadmap is written in past tense as a record.

### Cross-Team Decisions

The agent adds an "Impact Analysis" section and a "Cross-Team Coordination" subsection in the roadmap.

### Provisional Decisions

The agent sets status to `Proposed`, adds evaluation criteria and review date. No roadmap unless requested.

### Regulated Environments (SOC 2, HIPAA, PCI-DSS, GDPR, FedRAMP)

The agent adds "Compliance Impact" section and "Regulatory compliance" as a mandatory trade-off dimension. In the roadmap, adds "Compliance Milestones" subsection.

### No Clear Winner in Trade-offs

The agent highlights the tie, asks which dimensions to weight, and defaults to lowest reversibility cost.


---

## References

### trade-off-dimensions.md

# Trade-off Dimensions

This reference lists standard dimensions for evaluating architectural alternatives.
The agent selects the dimensions most relevant to the specific decision being documented.

## Core Dimensions

These dimensions apply to most architectural decisions:

| Dimension | What to Evaluate |
|-----------|------------------|
| **Complexity** | Implementation effort, cognitive load, learning curve for the team |
| **Scalability** | Ability to handle growth in users, data, or throughput |
| **Performance** | Latency, throughput, resource utilization under expected load |
| **Reliability** | Fault tolerance, recovery time, data durability |
| **Maintainability** | Ease of debugging, updating, and extending over time |
| **Cost** | Infrastructure costs, licensing, development time, operational overhead |
| **Security** | Attack surface, data protection, compliance alignment |
| **Team familiarity** | Existing team expertise and hiring availability |

## Situational Dimensions

The agent includes these when they are relevant to the specific context:

| Dimension | When to Include |
|-----------|-----------------|
| **Time to market** | When there is a hard deadline or competitive pressure |
| **Vendor lock-in** | When evaluating managed services or proprietary solutions |
| **Interoperability** | When the system must integrate with existing or third-party systems |
| **Observability** | When operational visibility is a stated concern |
| **Data consistency** | When the decision affects how data is stored, replicated, or synchronized |
| **Reversibility** | When the cost of changing the decision later is a factor |
| **Regulatory compliance** | When legal or industry regulations constrain the options |
| **Developer experience** | When tooling, debugging, or local development workflow matters |
| **Testability** | When the architecture must support automated testing at multiple levels |

## Rating Scale

| Rating | Meaning |
|--------|---------|
| **High** | Strong advantage — this option excels on this dimension |
| **Medium** | Adequate — meets requirements but is not a differentiator |
| **Low** | Weak — this option has notable limitations on this dimension |
| **N/A** | Not applicable — this dimension does not meaningfully apply |

Each rating must include a one-line justification.


### quality-checklist.md

# Architecture Document Quality Checklist

The agent validates every architecture document against this checklist before delivering
it to the user. Every item must pass.

## Problem Statement

- [ ] States the problem in business or user terms, not solution terms
- [ ] Explains why the problem needs to be solved now
- [ ] Is 2-5 sentences — not longer
- [ ] Does not mention the proposed solution

## Context

- [ ] Describes the current state of the system
- [ ] Lists relevant constraints (technical, organizational, regulatory)
- [ ] Identifies stakeholders affected by the decision
- [ ] Notes any relevant prior decisions or ADRs

## Alternatives

- [ ] At least 2 alternatives are listed
- [ ] No more than 5 alternatives are listed
- [ ] Each alternative has a clear name and summary
- [ ] A "status quo" option is included when applicable
- [ ] No straw-man alternatives (each must be genuinely viable)

## Trade-off Analysis

- [ ] Uses a comparison matrix (Markdown table)
- [ ] Dimensions are relevant to the specific decision
- [ ] Every cell has both a rating and a one-line justification
- [ ] At least 4 dimensions are evaluated
- [ ] No dimension is evaluated for only one alternative

## Decision

- [ ] The recommended option is stated explicitly
- [ ] Rationale references specific trade-off results
- [ ] Decision triggers for revisiting are documented
- [ ] For ADRs: status is one of Proposed, Accepted, Deprecated, Superseded

## Consequences

- [ ] Positive consequences are listed
- [ ] Negative consequences are listed
- [ ] Each consequence is concrete and specific (not vague)
- [ ] No consequence contradicts the trade-off analysis

## Diagrams (System Design and Tech Architecture only)

- [ ] At least one diagram is included
- [ ] Diagrams use Mermaid syntax
- [ ] Each diagram has a title and brief description
- [ ] Diagrams are relevant to the decision or design being documented

## Writing Quality

- [ ] Terminology is consistent throughout the document
- [ ] No placeholder text (TODO, TBD, TBC) remains
- [ ] Sections follow the template structure
- [ ] The document is readable by someone not present in the original discussion
- [ ] Acronyms are defined on first use

## Implementation Roadmap (Accepted ADRs only)

- [ ] Migration or build phases are ordered and have clear deliverables
- [ ] Dependencies and blockers are identified with mitigations
- [ ] Effort estimates use t-shirt sizes with rationale
- [ ] Success metrics are measurable and concrete (current value, target value, method)
- [ ] Rollback plan is documented with trigger, procedure, and estimated time


### document-type-guide.md

# Document Type Selection Guide

This reference helps the agent select and scope the correct document type based on the
user's request. The agent reads this file ONLY when the document type is ambiguous.

## Document Type Comparison

| Aspect | ADR | System Design Document | Technical Architecture Document |
|--------|-----|------------------------|----------------------------------|
| **Purpose** | Record a single decision | Design a new system or feature | Document overall system architecture |
| **Scope** | One decision point | One system or major feature | Entire system or platform |
| **Audience** | Future developers, reviewers | Implementation team, reviewers | All engineering stakeholders |
| **Lifespan** | Permanent record | Lives until system is built | Evolves with the system |
| **Typical length** | 1-3 pages (+ roadmap if Accepted) | 5-15 pages | 10-30 pages |

## Scope Signals

| Signal | Likely Type |
|--------|------------|
| "decide", "choose", "pick", "trade-offs between" | ADR |
| "design", "build", "implement", "new system" | System Design |
| "overview", "entire system", "onboarding", "platform" | Tech Architecture |

## Ambiguous Cases

| User Says | Likely Type | Why |
|-----------|------------|-----|
| "Document our API gateway" | Tech Architecture | Documenting existing system |
| "Design an API gateway" | System Design | Creating something new |
| "Should we use Kong or custom?" | ADR | Choosing between alternatives |


### writing-guide.md

# Architecture Writing Guide

Detailed examples and anti-patterns for architecture document writing. The agent reads
this file ONLY when it needs specific examples for a section it is struggling with.

## Problem Statement Examples

### Good

> Our order processing system handles 500 orders per minute during peak hours, but Black
> Friday projections show 3,000 orders per minute. The current synchronous processing
> pipeline cannot scale beyond 800 orders per minute without degrading response times
> below our 2-second SLO. If we do not address this before October, we risk significant
> revenue loss during our highest-traffic period.

### Bad

> We need to implement Kafka for our order processing system because the current
> architecture is not scalable enough and we should use event-driven architecture.

**Why bad:** Names the solution, vague language, no urgency.

## Anti-Patterns

| Anti-Pattern | Fix |
|-------------|-----|
| Solution in disguise | State the latency problem, not the fix |
| Vague urgency | Quantify: "exceeds SLO 12% of requests" |
| Missing "why now" | Add trigger: "SOC 2 audit in Q3" |
| Straw-man alternative | Ask: "Would a reasonable engineer choose this?" |
| Vague consequence | "p99 drops to 200ms" not "system is faster" |
| Weak rationale | Reference 2+ trade-off dimensions by name |

## Consequences Examples

### Good
> - Order processing throughput increases from 800 to 5,000 orders per minute.
> - Team must learn SQS and Lambda patterns, estimated 2-week ramp-up.

### Bad
> - System will be better.
> - Some complexity.


### diagram-guide.md

# Diagram Selection and Mermaid Syntax Guide

The agent reads this file ONLY when it needs Mermaid syntax for a specific diagram type.

## Diagram Selection by Document Type

| Document Type | Required | Recommended |
|--------------|----------|-------------|
| ADR | None | Before/after if decision changes interactions |
| System Design | System overview | Sequence diagrams, deployment diagram |
| Tech Architecture | Context + overview | Data flow, deployment, interaction flows |

## Common Patterns

### Context Diagram
```mermaid
graph TD
    Users["Users"] --> System["Our System"]
    System --> ExtAPI["External API"]
    OtherSvc["Other Service"] --> System
```

### Sequence Diagram
```mermaid
sequenceDiagram
    participant U as User
    participant A as Service A
    participant B as Service B
    U->>A: Request
    A->>B: Process
    B-->>A: Response
    A-->>U: Result
```

### Deployment Diagram
```mermaid
graph LR
    LB[Load Balancer] --> S1[Server 1]
    LB --> S2[Server 2]
    S1 --> DB[(Database)]
    S2 --> DB
```

## Rules
- Title every diagram with a heading and one-sentence description
- Label arrows with protocols or actions
- Keep to 7-12 nodes; split if more complex
- Node names must match terminology in the text


### problem-statement-validation.md

# Problem Statement Quality Checklist

The problem statement is the foundation of every architecture document. A weak problem
statement leads to poorly justified decisions, vague trade-offs, and documents that fail
to persuade reviewers. The agent reads this file when writing the problem statement section
and validates its draft against the checklist below.

## Quality Checklist

Every problem statement must satisfy all five criteria:

- [ ] **Business/user language**: Describes the problem in terms of user impact, business
  outcomes, or operational pain — not implementation details or technology names.
- [ ] **No solution language**: Does not mention the proposed solution, specific technologies,
  or architectural patterns. The problem statement frames the *need*, not the *fix*.
- [ ] **Quantified scope**: Includes at least one concrete metric, threshold, or measurable
  impact (e.g., error rates, latency numbers, user counts, revenue figures, SLO breaches).
- [ ] **Explains "why now"**: States a clear trigger — a deadline, a threshold being crossed,
  a compliance date, a scaling inflection point — that makes this decision urgent.
- [ ] **2-5 sentences**: Long enough to convey context, short enough to stay focused. If it
  takes more than 5 sentences, details belong in the Context section instead.

## Before/After Examples

### Example 1: Solution-Focused Language

**Before (bad):**
> We need to migrate to Kafka because our current RabbitMQ setup can't handle the load
> and event-driven architecture is the industry best practice for high-throughput systems.

**What's wrong:** Names both the current technology and the proposed solution (Kafka).
Appeals to "best practice" instead of a concrete problem. Doesn't quantify "the load"
or explain why this is urgent now.

**After (good):**
> Our order ingestion pipeline processes 12,000 events per second at peak, but traffic
> projections for the holiday season show 45,000 events per second. The current message
> broker begins dropping messages above 18,000 events per second, which causes order
> loss and requires manual reconciliation. We need to resolve this before the November
> traffic ramp begins.

**Why it works:** Quantifies current capacity (12k eps), projected need (45k eps), and
failure threshold (18k eps). States the consequence (order loss) and the deadline
(November traffic ramp). No technology names in the problem.

### Example 2: Vague Scope

**Before (bad):**
> Our system is slow and users are complaining. We need to improve performance to
> provide a better user experience.

**What's wrong:** "Slow" and "better" are unmeasurable. No indication of which part of
the system, how many users are affected, or what "good" looks like.

**After (good):**
> The product search API has a p99 latency of 4.2 seconds, which exceeds our 1-second
> SLO and is the top driver of cart abandonment — 23% of users who experience a slow
> search drop off before completing a purchase. Our peak traffic season starts in 8 weeks.

**Why it works:** Pinpoints the specific component (product search API), quantifies the
gap (4.2s actual vs 1s SLO), ties it to business impact (23% cart abandonment), and
states urgency (8 weeks to peak).

### Example 3: Missing Urgency

**Before (bad):**
> Our authentication system uses session-based auth, which doesn't work well for our
> mobile apps. We should probably move to token-based auth at some point since it would
> be more modern and easier to work with.

**What's wrong:** "At some point" and "probably" signal no urgency. "More modern" is
not a business justification. Mentions the solution direction (token-based auth).

**After (good):**
> Our mobile apps must re-authenticate users on every app restart because session cookies
> are not persisted across app launches on iOS and Android. This causes 40% of mobile
> users to log in more than 3 times per day, and our mobile NPS score has dropped from
> 42 to 28 over the past quarter — with "login friction" cited in 65% of negative
> reviews. The mobile team is blocked on shipping the offline mode feature until
> authentication can survive app restarts.

**Why it works:** Describes the user-facing symptom (re-authentication), quantifies impact
(40% of users, NPS drop, review citations), and states what is blocked (offline mode
feature). No mention of token-based auth or any solution.

### Example 4: Too Long / Context Bleed

**Before (bad):**
> Our data pipeline was originally built in 2019 when we had 50 customers. At the time,
> we chose a batch processing approach using cron jobs that run every 6 hours. The team
> that built it has since left the company. Over the years, we've added more data sources
> including Salesforce, HubSpot, and our custom event tracking system. The pipeline now
> processes data from 12 sources and serves 3 internal dashboards plus the customer-facing
> analytics feature we launched last year. Recently, customers have been asking for
> real-time data and our largest enterprise client threatened to churn if we can't deliver
> sub-minute data freshness by Q3. The current 6-hour batch cycle means customers see
> stale data for most of the day. Also, the pipeline fails about twice a week and takes
> 2-4 hours to recover because the original team didn't write documentation.

**What's wrong:** This is 8 sentences mixing historical context, current architecture
details, and the actual problem. The real problem is buried.

**After (good):**
> Our data pipeline delivers analytics with a 6-hour delay, but our largest enterprise
> client requires sub-minute data freshness by Q3 or will churn — representing $2.1M ARR.
> Three other enterprise prospects have the same requirement in their RFPs. The pipeline
> also fails twice weekly with 2-4 hour recovery times, eroding customer trust.

**Why it works:** Four sentences focused on the problem: the gap (6-hour vs sub-minute),
the business consequence ($2.1M churn risk + pipeline prospects), and operational pain
(failure frequency). Historical context and architecture details belong in the Context
section.

## Common Mistakes Reference

| Mistake | How to Spot It | How to Fix It |
|---------|---------------|---------------|
| Solution in disguise | Mentions technology names, patterns, or migration targets | Remove technology names; describe the *pain* not the *cure* |
| Vague scope | Uses words like "slow", "better", "improve", "scalable" without numbers | Add a specific metric and its current vs required value |
| Missing urgency | No deadline, threshold, blocker, or consequence mentioned | Add what happens if nothing changes and when it happens |
| Appeal to best practice | Justifies with "industry standard" or "modern" instead of data | Replace with a measurable business or user impact |
| Context bleed | More than 5 sentences; includes history or architecture details | Move history to Context section; keep only the core problem |
| Assumed audience knowledge | References internal systems or acronyms without explanation | Define terms or explain enough for a new team member to understand |



---

## Scripts

### next-adr-number.sh

```sh
#!/bin/bash
set -euo pipefail

# Scans a directory for existing ADR files and returns the next sequential number.
# Usage: next-adr-number.sh <adr-directory>
# Output: The next ADR number zero-padded to 4 digits (e.g., "0005")
# Exit codes:
#   0 - success
#   1 - invalid arguments or directory not found

if [[ $# -ne 1 ]]; then
  echo "Error: Expected exactly 1 argument: <adr-directory>" >&2
  echo "Usage: next-adr-number.sh <adr-directory>" >&2
  exit 1
fi

ADR_DIR="$1"

if [[ ! -d "$ADR_DIR" ]]; then
  echo "Error: Directory not found: $ADR_DIR" >&2
  echo "Hint: Create the directory first or check the path." >&2
  exit 1
fi

# Find the highest ADR number by scanning filenames matching NNNN-*.md pattern
max_number=0
for file in "$ADR_DIR"/[0-9][0-9][0-9][0-9]-*.md; do
  # Handle case where glob matches nothing
  [[ -e "$file" ]] || continue
  basename_file=$(basename "$file")
  # Extract the leading 4-digit number
  num_str="${basename_file:0:4}"
  # Remove leading zeros for arithmetic comparison
  num=$((10#$num_str))
  if (( num > max_number )); then
    max_number=$num
  fi
done

next_number=$((max_number + 1))
printf "%04d\n" "$next_number"

```

### validate-doc.sh

```sh
#!/bin/bash
set -euo pipefail

# Validates an architecture document for common structural issues.
# Usage: validate-doc.sh <document-path> <document-type>
#   document-type: adr | system-design | tech-architecture
# Output: List of issues found, or "PASS: No issues found." if valid.
# Exit codes:
#   0 - validation passed (no issues)
#   1 - invalid arguments
#   2 - validation failed (issues found)

if [[ $# -ne 2 ]]; then
  echo "Error: Expected 2 arguments: <document-path> <document-type>" >&2
  echo "Usage: validate-doc.sh <document-path> <document-type>" >&2
  echo "  document-type: adr | system-design | tech-architecture" >&2
  exit 1
fi

DOC_PATH="$1"
DOC_TYPE="$2"

if [[ ! -f "$DOC_PATH" ]]; then
  echo "Error: File not found: $DOC_PATH" >&2
  exit 1
fi

if [[ "$DOC_TYPE" != "adr" && "$DOC_TYPE" != "system-design" && "$DOC_TYPE" != "tech-architecture" ]]; then
  echo "Error: Invalid document type '$DOC_TYPE'. Must be one of: adr, system-design, tech-architecture" >&2
  exit 1
fi

issues=()
content=$(cat "$DOC_PATH")

# --- Check for placeholder text ---
for placeholder in "TODO" "TBD" "TBC" "FIXME" "XXX" "\[description\]" "\[Name\]" "\[name\]"; do
  if grep -qiE "$placeholder" "$DOC_PATH"; then
    issues+=("PLACEHOLDER: Found '$placeholder' — replace with actual content.")
  fi
done

# --- Check for required sections (all types) ---
required_sections=("Problem Statement" "Alternatives" "Trade-off" "Decision" "Consequences")
for section in "${required_sections[@]}"; do
  if ! grep -qi "$section" "$DOC_PATH"; then
    issues+=("MISSING SECTION: '$section' section not found.")
  fi
done

# --- Check for trade-off table ---
if ! grep -qE '^\|.*\|.*\|' "$DOC_PATH"; then
  issues+=("MISSING TABLE: No Markdown table found — trade-off analysis requires a comparison matrix.")
fi

# --- Check for empty sections (heading followed by another heading or end of file) ---
while IFS= read -r line_num; do
  issues+=("EMPTY SECTION: Section at line $line_num appears to have no content.")
done < <(awk '
  /^##/ {
    if (prev_heading_line > 0 && content_lines == 0) {
      print prev_heading_line
    }
    prev_heading_line = NR
    content_lines = 0
    next
  }
  /^[[:space:]]*$/ { next }
  { content_lines++ }
  END {
    if (prev_heading_line > 0 && content_lines == 0) {
      print prev_heading_line
    }
  }
' "$DOC_PATH")

# --- Check for Mermaid diagrams (system-design and tech-architecture only) ---
if [[ "$DOC_TYPE" == "system-design" || "$DOC_TYPE" == "tech-architecture" ]]; then
  if ! grep -q '```mermaid' "$DOC_PATH"; then
    issues+=("MISSING DIAGRAM: No Mermaid diagram found — system design and tech architecture documents require at least one diagram.")
  fi
fi

# --- ADR-specific checks ---
if [[ "$DOC_TYPE" == "adr" ]]; then
  if ! grep -qiE '\*\*Status:\*\*' "$DOC_PATH"; then
    issues+=("MISSING FIELD: ADR is missing a '**Status:**' field.")
  fi
  if ! grep -qiE '\*\*Date:\*\*' "$DOC_PATH"; then
    issues+=("MISSING FIELD: ADR is missing a '**Date:**' field.")
  fi
  # Check for implementation roadmap if status is Accepted
  if grep -qi '\*\*Status:\*\* *Accepted' "$DOC_PATH"; then
    if ! grep -qi 'Implementation Roadmap' "$DOC_PATH"; then
      issues+=("MISSING SECTION: Accepted ADR is missing an 'Implementation Roadmap' section.")
    fi
    if ! grep -qi 'Success Metrics' "$DOC_PATH"; then
      issues+=("MISSING SECTION: Accepted ADR is missing a 'Success Metrics' section.")
    fi
    if ! grep -qi 'Rollback Plan' "$DOC_PATH"; then
      issues+=("MISSING SECTION: Accepted ADR is missing a 'Rollback Plan' section.")
    fi
  fi
fi

# --- Report results ---
if [[ ${#issues[@]} -eq 0 ]]; then
  echo "PASS: No issues found."
  exit 0
else
  echo "FAIL: Found ${#issues[@]} issue(s):"
  for issue in "${issues[@]}"; do
    echo "  - $issue"
  done
  exit 2
fi

```

### list-adrs.sh

```sh
#!/bin/bash
set -euo pipefail

# Lists all ADRs in a directory with their status, title, and date.
# Usage: list-adrs.sh <adr-directory>
# Output: Formatted table of ADRs sorted by number.
# Exit codes:
#   0 - success
#   1 - invalid arguments or directory not found

if [[ $# -ne 1 ]]; then
  echo "Error: Expected exactly 1 argument: <adr-directory>" >&2
  echo "Usage: list-adrs.sh <adr-directory>" >&2
  exit 1
fi

ADR_DIR="$1"

if [[ ! -d "$ADR_DIR" ]]; then
  echo "Error: Directory not found: $ADR_DIR" >&2
  echo "Hint: Create the directory first or check the path." >&2
  exit 1
fi

# Collect ADR files
adr_files=()
for file in "$ADR_DIR"/[0-9][0-9][0-9][0-9]-*.md; do
  [[ -e "$file" ]] || continue
  adr_files+=("$file")
done

if [[ ${#adr_files[@]} -eq 0 ]]; then
  echo "No ADRs found in $ADR_DIR"
  echo "Hint: ADR files should follow the naming convention NNNN-short-title.md"
  exit 0
fi

# Print header
printf "%-6s | %-12s | %-12s | %s\n" "NUM" "STATUS" "DATE" "TITLE"
printf "%-6s-+-%-12s-+-%-12s-+-%s\n" "------" "------------" "------------" "----------------------------------------"

# Process each ADR file sorted by name
for file in $(printf '%s\n' "${adr_files[@]}" | sort); do
  basename_file=$(basename "$file")
  num="${basename_file:0:4}"

  # Extract title from first H1 heading
  title=$(grep -m1 '^# ' "$file" | sed 's/^# //' | sed "s/^ADR-${num}: *//" || echo "(no title)")

  # Extract status from **Status:** field
  status=$(grep -i '\*\*Status:\*\*' "$file" | head -1 | sed 's/.*\*\*Status:\*\* *//' | sed 's/[[:space:]]*$//' || echo "(unknown)")

  # Extract date from **Date:** field
  date=$(grep -i '\*\*Date:\*\*' "$file" | head -1 | sed 's/.*\*\*Date:\*\* *//' | sed 's/[[:space:]]*$//' || echo "(no date)")

  printf "%-6s | %-12s | %-12s | %s\n" "$num" "$status" "$date" "$title"
done

echo ""
echo "Total: ${#adr_files[@]} ADR(s)"

```


---

## Assets

### adr-template.md

```md
# ADR-NNNN: [Short Title]

**Status:** [Proposed | Accepted | Deprecated | Superseded]
**Date:** [YYYY-MM-DD]
**Decision makers:** [Names or roles]

## Context

[Describe the current situation, the forces at play, and why a decision is needed now.
Include relevant technical and organizational constraints.]

## Problem Statement

[A clear, concise statement of the problem being addressed. 2-5 sentences.
Do not mention the proposed solution here.]

## Alternatives Considered

### Option 1: [Name]

[One-sentence summary.]

- How it addresses the problem: [description]
- Key characteristics: [description]

### Option 2: [Name]

[One-sentence summary.]

- How it addresses the problem: [description]
- Key characteristics: [description]

### Option 3: [Name] (if applicable)

[One-sentence summary.]

- How it addresses the problem: [description]
- Key characteristics: [description]

## Trade-off Analysis

| Dimension | Option 1 | Option 2 | Option 3 |
|-----------|----------|----------|----------|
| [Dim 1]   | [Rating — justification] | [Rating — justification] | [Rating — justification] |
| [Dim 2]   | [Rating — justification] | [Rating — justification] | [Rating — justification] |
| [Dim 3]   | [Rating — justification] | [Rating — justification] | [Rating — justification] |
| [Dim 4]   | [Rating — justification] | [Rating — justification] | [Rating — justification] |

## Decision

[State the chosen option and explain why it was selected over the alternatives.
Reference specific trade-off results.]

## Consequences

### Positive

- [Concrete benefit 1]
- [Concrete benefit 2]

### Negative

- [Concrete cost or risk 1]
- [Concrete cost or risk 2]

### Neutral

- [Change that is neither clearly positive nor negative]

## Decision Triggers

[List conditions under which this decision should be revisited.]

- [Trigger 1]
- [Trigger 2]

```

### system-design-template.md

```md
# System Design: [System or Feature Name]

**Author:** [Name]
**Date:** [YYYY-MM-DD]
**Status:** [Draft | In Review | Approved]
**Reviewers:** [Names or roles]

## Problem Statement

[A clear, concise statement of the problem being addressed. 2-5 sentences.
Do not mention the proposed solution here.]

## Context

[Describe the current state of the system, relevant history, and why this design
is needed now. Include links to related ADRs if applicable.]

### Constraints

- [Technical constraint 1]
- [Organizational constraint 1]
- [Regulatory constraint 1, if applicable]

### Assumptions

- [Assumption 1]
- [Assumption 2]

## Goals and Non-Goals

### Goals

- [Goal 1]
- [Goal 2]

### Non-Goals

- [Non-goal 1 — explicitly out of scope]
- [Non-goal 2]

## System Overview

[High-level description of the proposed system design.]

```mermaid
graph TD
    A[Component A] --> B[Component B]
    B --> C[Component C]
```

## Detailed Design

### Component 1: [Name]

[Description of the component, its responsibilities, and interfaces.]

### Component 2: [Name]

[Description of the component, its responsibilities, and interfaces.]

### Data Model

[Describe key data structures, storage choices, and data flow.]

### API Design

[Describe key API endpoints or interfaces, request/response formats.]

## Alternatives Considered

### Option 1: [Name]

[Summary and why it was not chosen.]

### Option 2: [Name]

[Summary and why it was not chosen.]

## Trade-off Analysis

| Dimension | Proposed Design | Alternative 1 | Alternative 2 |
|-----------|----------------|---------------|---------------|
| [Dim 1]   | [Rating — justification] | [Rating — justification] | [Rating — justification] |
| [Dim 2]   | [Rating — justification] | [Rating — justification] | [Rating — justification] |
| [Dim 3]   | [Rating — justification] | [Rating — justification] | [Rating — justification] |
| [Dim 4]   | [Rating — justification] | [Rating — justification] | [Rating — justification] |

## Key Interactions

```mermaid
sequenceDiagram
    participant U as User
    participant A as Service A
    participant B as Service B
    U->>A: Request
    A->>B: Process
    B-->>A: Response
    A-->>U: Result
```

## Deployment and Infrastructure

[Describe how the system will be deployed, infrastructure requirements,
and any operational considerations.]

## Security Considerations

- [Security consideration 1]
- [Security consideration 2]

## Observability

- **Logging:** [What will be logged and where]
- **Metrics:** [Key metrics to track]
- **Alerting:** [What conditions trigger alerts]

## Rollout Plan

1. [Phase 1: description]
2. [Phase 2: description]
3. [Phase 3: description]

## Consequences

### Positive

- [Benefit 1]
- [Benefit 2]

### Negative

- [Cost or risk 1]
- [Cost or risk 2]

### Neutral

- [Change 1]

```

### tech-architecture-template.md

```md
# Technical Architecture: [System or Platform Name]

**Author:** [Name]
**Date:** [YYYY-MM-DD]
**Status:** [Draft | In Review | Approved]
**Version:** [1.0]

## Purpose

[One paragraph explaining what this document covers and who it is for.]

## Problem Statement

[A clear, concise statement of the problem or need this architecture addresses.
2-5 sentences. Do not mention the proposed solution here.]

## Architectural Principles

1. **[Principle 1]** — [One-sentence explanation]
2. **[Principle 2]** — [One-sentence explanation]
3. **[Principle 3]** — [One-sentence explanation]

## System Context

[Describe how this system fits into the broader ecosystem.]

```mermaid
graph TD
    External1[External System 1] --> System[Our System]
    External2[External System 2] --> System
    System --> External3[External System 3]
    Users[Users] --> System
```

## Architecture Overview

[High-level description of the architecture style and key components.]

```mermaid
graph TD
    subgraph Frontend
        UI[Web UI]
        Mobile[Mobile App]
    end
    subgraph Backend
        API[API Gateway]
        Svc1[Service 1]
        Svc2[Service 2]
    end
    subgraph Data
        DB[(Primary DB)]
        Cache[(Cache)]
        Queue[Message Queue]
    end
    UI --> API
    Mobile --> API
    API --> Svc1
    API --> Svc2
    Svc1 --> DB
    Svc1 --> Cache
    Svc2 --> Queue
```

## Component Details

### [Component 1 Name]

- **Responsibility:** [What it does]
- **Technology:** [Tech stack]
- **Interfaces:** [APIs or protocols it exposes]
- **Dependencies:** [What it depends on]

## Data Architecture

### Data Flow

[Describe how data moves through the system.]

### Storage

| Data Store | Technology | Purpose | Consistency Model |
|-----------|------------|---------|-------------------|
| [Store 1] | [Tech]     | [Purpose] | [Model]         |

## Infrastructure and Deployment

[Describe the deployment topology and infrastructure.]

## Cross-Cutting Concerns

### Security
- **Authentication:** [Method]
- **Authorization:** [Method]
- **Data encryption:** [At rest and in transit approach]

### Observability
- **Logging:** [Approach and tools]
- **Metrics:** [Key metrics and tools]
- **Alerting:** [Alert conditions and escalation]

### Reliability
- **SLO:** [Target availability and latency]
- **Failover:** [Strategy]
- **Disaster recovery:** [RPO and RTO targets]

## Alternatives Considered

### Option 1: [Name]
[Summary and why it was not chosen.]

## Trade-off Analysis

| Dimension | Current Architecture | Alternative 1 |
|-----------|---------------------|---------------|
| [Dim 1]   | [Rating — justification] | [Rating — justification] |

## Consequences

### Positive
- [Benefit 1]

### Negative
- [Cost or risk 1]

## Decision Log

| Decision | ADR | Date | Status |
|----------|-----|------|--------|
| [Decision 1] | [Link] | [Date] | [Status] |

## Evolution Plan

1. **Short term (0-3 months):** [Plans]
2. **Medium term (3-12 months):** [Plans]
3. **Long term (1+ years):** [Plans]

```

### implementation-plan-template.md

```md
## Implementation Roadmap

### Current State Assessment

[Describe the existing system state that will change as a result of this decision.
Include relevant components, data flows, and integration points that are affected.]

### Migration Phases

#### Phase 1: [Phase Name]

- **Objective:** [What this phase achieves]
- **Deliverable:** [Concrete output — deployed service, migrated data, updated API]
- **Effort:** [S / M / L / XL] — [One-sentence rationale for the estimate]
- **Steps:**
  1. [Step 1]
  2. [Step 2]
  3. [Step 3]

#### Phase 2: [Phase Name]

- **Objective:** [What this phase achieves]
- **Deliverable:** [Concrete output]
- **Effort:** [S / M / L / XL] — [Rationale]
- **Steps:**
  1. [Step 1]
  2. [Step 2]
  3. [Step 3]

#### Phase 3: [Phase Name] (if applicable)

- **Objective:** [What this phase achieves]
- **Deliverable:** [Concrete output]
- **Effort:** [S / M / L / XL] — [Rationale]
- **Steps:**
  1. [Step 1]
  2. [Step 2]

### Dependencies and Blockers

| Dependency | Type | Owner | Status | Mitigation if Blocked |
|-----------|------|-------|--------|-----------------------|
| [Dependency 1] | Technical / Team / External | [Team or person] | [Ready / In Progress / Blocked] | [What to do if this is not available] |
| [Dependency 2] | Technical / Team / External | [Team or person] | [Status] | [Mitigation] |

## Success Metrics

| Metric | Current Value | Target Value | Measurement Method |
|--------|--------------|-------------|--------------------|
| [Metric 1, e.g., p99 latency] | [Current, e.g., 850ms] | [Target, e.g., < 200ms] | [How measured, e.g., Datadog APM dashboard] |
| [Metric 2, e.g., deployment frequency] | [Current] | [Target] | [Method] |
| [Metric 3, e.g., error rate] | [Current] | [Target] | [Method] |

## Rollback Plan

- **Trigger:** [Condition that activates rollback, e.g., error rate exceeds 5% for 10 minutes]
- **Procedure:**
  1. [Rollback step 1, e.g., revert feature flag to OFF]
  2. [Rollback step 2, e.g., switch DNS back to old service]
  3. [Rollback step 3, e.g., verify traffic is flowing to old system]
- **Data considerations:** [How to handle data written during the failed migration, e.g., dual-write reconciliation]
- **Estimated rollback time:** [Duration, e.g., < 15 minutes]

```
